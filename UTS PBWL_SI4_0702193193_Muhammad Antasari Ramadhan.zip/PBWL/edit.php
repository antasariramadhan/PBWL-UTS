<?php 
include "app/koneksi.php";
$sql = mysqli_query($koneksi, "Select * From tb_artist
where art_id= '$_GET[kode]'");
$data =mysqli_fetch_array($sql);
$sql = mysqli_query($koneksi, "Select * From tb_album
where alb_id= '$_GET[kode]'");
$data =mysqli_fetch_array($sql);
$sql = mysqli_query($koneksi, "Select * From tb_track
where trc_id= '$_GET[kode]'") ;
$data =mysqli_fetch_array($sql);
$sql = mysqli_query($koneksi, "Select * From tb_played
where ply_id= '$_GET[kode]'");
$data =mysqli_fetch_array($sql);
?>

<?php
require_once "app/musik.php";


$Artis1 = new artis1();
$rows = $Artis1->update();
?>
<?php
require_once "app/musik.php";


$Album1 = new album1();
$rows = $Album1->update();
?>
<?php
require_once "app/musik.php";


$Track1 = new track1();
$rows = $Track1->update();
?>
<?php
require_once "app/musik.php";


$Play1 = new play1();
$rows = $Play1->update();
?>

<form action="" method="post">
    <table>
        <tr>
            <td width="130">Nama Artis</td>
            <td><input type="text" name="art_name" ></td>
        </tr>
        <tr>
            <td>Nama Album</td>
            <td><input type="text" name="alb_name" ></td>
        </tr>
        <tr>
            <td>Nama Track</td>
            <td><input type="text" name="trc_name" ></td>
        </tr>
        <tr>
            <td>Play</td>
            <td><input type="text" name="ply_played" value="<?php echo date('Y-m-d H:i:s'); ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="t_update" value="SIMPAN"></td>
        </tr>
    </table>
</form>