<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="layouts/assets/css/style.css" />
    <link rel="stylesheet" href="layouts/assets/css/tabel.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
</head>

<body>

    <div class="akun">
        <div class="container">
            
        </div>
    </div>
    <header>
        <div class="container">
            <h1>MUSIK</h1>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php?page=artis">Artist</a></li>
                <li><a href="index.php?page=informasi" class="active">Informasi</a></li>
                <li><a href="index.php?page=logout">Logout</a></li>
            </ul>
        </div>
    </header>
    <section class="banner">
        <h2>Welcome to My Website </h2>
    </section>

    <section class="about">
        <div class="container1">
            <h3>Data Musik</h3>

            <table border="1">
                <tr>
                    <th width="50">No</th>
                    <th width="150">Nama Artis</th>
                    <th width="150">Nama Album</th>
                    <th width="150">Nama Track</th>
                    <th width="200">Tanggal Pemutaran</th>
                    <th colspan="2">Aksi</th>
                </tr>


                <?php
                include "app/koneksi.php";

                $no = 1;
                $ambildata = mysqli_query($koneksi, "Select * From tb_artist, tb_album, tb_track, tb_played
                where tb_artist.art_id = tb_album.alb_id and tb_artist.art_id = tb_track.trc_id and tb_artist.art_id= tb_played.ply_id") or die(mysqli_error($koneksi));
                while ($tampil = mysqli_fetch_array($ambildata)) {
                    $warna = ($no % 2 == 1) ? "white" : "#eee";

                    echo "
                    <tr >
                    <td align ='center'>$no</td>
                    <td>$tampil[art_name]</td>
                    <td>$tampil[alb_name]</td>
                    <td>$tampil[trc_name]</td>
                    <td>$tampil[ply_played]</td>
                    <td><a href='hapus.php?del=$tampil[art_id]'>Hapus</a></td>
                    <td ><a href='edit.php?kode=$tampil[art_id]'>Edit</a>
                    </tr>";
                    $no++;
                }

                ?>
                
            </table>

        </div>
    </section>

</body>

</html>