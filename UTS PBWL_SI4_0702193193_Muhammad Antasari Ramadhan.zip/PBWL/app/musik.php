<?php

class artis
{

    public function tampil()
    {
        if (isset($_POST['t_simpan'])) {
            include "koneksi.php";
            mysqli_query($koneksi, "insert into tb_artist set
            art_name = '$_POST[art_name]'") or die(mysqli_error($koneksi));

            echo "<script>alert('Data telah tersimpan')</script>";
        }
    }
}
class   artis1
{
    public function update()
    {
        if (isset($_POST['t_update'])) {
            include "koneksi.php";
            mysqli_query($koneksi, "update tb_artist set
        art_name = '$_POST[art_name]'
        where art_id = '$_GET[kode]'");

            echo "<script>alert('Data telah di update')</script>";
        }
    }
}

class album
{
    public function tampil()
    {
        if (isset($_POST['t_simpan'])) {
            include "koneksi.php";
            mysqli_query($koneksi, "insert into tb_album set
            alb_name = '$_POST[alb_name]'") or die(mysqli_error($koneksi));

            echo "<script>alert('Data telah tersimpan')</script>";
        }
    }
}
class album1
{
    public function update()
    {
        if (isset($_POST['t_update'])) {
            include "koneksi.php";
            mysqli_query($koneksi, "update tb_album set
            alb_name = '$_POST[alb_name]'
            where alb_id = '$_GET[kode]'");

            echo "<script>alert('Data telah di update')</script>";
        }
    }
}

class track
{
    public function tampil()
    {
        if (isset($_POST['t_simpan'])) {
            include "koneksi.php";
            mysqli_query($koneksi, "insert into tb_track set
            trc_name = '$_POST[trc_name]'") or die(mysqli_error($koneksi));

            echo "<script>alert('Data telah tersimpan')</script>";
        }
    }
}
class track1
{
    public function update()
    {
        if (isset($_POST['t_update'])) {
            include "koneksi.php";
            mysqli_query($koneksi, "update tb_track set
            trc_name = '$_POST[trc_name]'
            where trc_id = '$_GET[kode]'");

            echo "<script>alert('Data telah di update')</script>";
        }
    }
}

class play
{

    public function tampil()
    {
        if (isset($_POST['t_simpan'])) {
            include "koneksi.php";
            mysqli_query($koneksi, "insert into tb_played set
            ply_played = '$_POST[ply_played]'") or die(mysqli_error($koneksi));

            echo "<script>alert('Data telah tersimpan')</script>";
        }
    }
}
class play1
{
    public function update()
    {
        if (isset($_POST['t_update'])) {
            include "koneksi.php";
            mysqli_query($koneksi, "update tb_played set
            ply_played = '$_POST[ply_played]'
            where ply_id = '$_GET[kode]'");

            echo "<script>alert('Data telah di update')</script>";
        }
    }
}
class hapus {
    public function delete()
    {
    
        include 'koneksi.php';
        if (isset($_POST['del'])) {
            mysqli_query($koneksi, "delete from tb_artist where art_id = '$_GET[del]'");
        
            echo "<script>alert('Data telah di hapus')</script>";
        }
        
        
    }
}
class hapus1 {
    public function delete()
    {
    
        include 'koneksi.php';
        if (isset($_POST['del'])) {
            mysqli_query($koneksi, "delete from tb_album where alb_id = '$_GET[del]'");
        
            echo "<script>alert('Data telah di hapus')</script>";
        }
        
        
    }
}
class hapus2 {
    public function delete()
    {
    
        include 'koneksi.php';
        if (isset($_POST['del'])) {
            mysqli_query($koneksi, "delete from tb_track where trc_id = '$_GET[del]'");
        
            echo "<script>alert('Data telah di hapus')</script>";
        }
        
        
    }
}
class hapus3 {
    public function delete()
    {
    
        include 'koneksi.php';
        if (isset($_POST['del'])) {
            mysqli_query($koneksi, "delete from tb_played where ply_id = '$_GET[del]'");
        
            echo "<script>alert('Data telah di hapus')</script>";
        }
        
        
    }
}