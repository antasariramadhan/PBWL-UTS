<?php 
$dbhost = "localhost";
$dbname = "dbmusik";
$dbuser = "root";
$dbpass = "";

$koneksi = mysqli_connect ($dbhost,$dbuser,$dbpass,$dbname)
or die(mysqli_connect_error());
?>