    <div class="akun">
        <div class="container">
         
        </div>
    </div>
    <header>
        <div class="container">
            <h1>MUSIK</h1>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php?page=artis" class="active">Arstist</a></li>
                <li><a href="index.php?page=informasi">Informasi</a></li>
                <li><a href="index.php?page=logout">Logout</a></li>
            </ul>
        </div>
    </header>

    <?php
    require_once "app/musik.php";


    $Artis = new artis();
    $rows = $Artis->tampil();
    ?>

    <?php
    require_once "app/musik.php";

    $Album = new album();
    $rows = $Album->tampil();
    ?>

    <?php
    require_once "app/musik.php";


    $Track = new track();
    $rows = $Track->tampil();
    ?>

    <?php
    require_once "app/musik.php";


    $Play = new play();
    $rows = $Play->tampil();
    ?>
    <section class="banner">
        <h2>Welcome to My Website </h2>
    </section>
    <section class="about">
        <div class="container">
            <h3>Input Data Artis</h3>

            <form action="" method="post">
                <table>
                    <tr>
                        <td width = "130">Nama Artis</td>
                        <td><input type="text" name="art_name"></td>
                    </tr>
                    <tr>
                        <td>Nama Album</td>
                        <td><input type="text" name="alb_name"></td>
                    </tr>
                    <tr>
                        <td>Nama Track</td>
                        <td><input type="text" name="trc_name"></td>
                    </tr>
                    <tr>
                        <td>Play</td>
                        <td><input type="text" name="ply_played" value="<?php echo date('Y-m-d H:i:s'); ?>"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" name="t_simpan" value="SIMPAN"></td>
                    </tr>
                </table>
            </form>

        </div>
    </section>