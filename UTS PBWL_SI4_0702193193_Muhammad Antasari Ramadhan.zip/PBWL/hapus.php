
<?php
require_once "app/musik.php";


$Hapus = new hapus();
$rows = $Hapus->delete();
?>
<?php
require_once "app/musik.php";


$Hapus1 = new hapus1();
$rows = $Hapus1->delete();
?>
<?php
require_once "app/musik.php";


$Hapus2 = new hapus2();
$rows = $Hapus2->delete();
?>
<?php
require_once "app/musik.php";


$Hapus3 = new hapus3();
$rows = $Hapus3->delete();
?>

<form action="" method="post">
    <table>
        <tr>
            <td width="130">Nama Artis</td>
            <td><input type="text" name="art_name" ></td>
        </tr>
        <tr>
            <td>Nama Album</td>
            <td><input type="text" name="alb_name" ></td>
        </tr>
        <tr>
            <td>Nama Track</td>
            <td><input type="text" name="trc_name" ></td>
        </tr>
        <tr>
            <td>Play</td>
            <td><input type="text" name="ply_played" value="<?php echo date('Y-m-d H:i:s'); ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" name="del" value="HAPUS"></td>
        </tr>
    </table>
</form>